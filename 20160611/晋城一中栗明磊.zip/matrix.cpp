#include <cstdio>
#include <algorithm>
#include <set>
#include <cmath>
using namespace std;
#define F(i, x, y) for (int i = x; i <= y; i++)
#define F0(i, n) for (int i = 0; i < n; i++)
#define F1(i, n) for (int i = 1; i <= n; i++)
int n,m;
int c[110][110];
int a[110],b[110];
int main(){
  freopen("matrix.out","w",stdout);
  printf("NO");
}
